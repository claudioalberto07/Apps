import 'package:calc/PageMainCalcIMC.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(CalcIMC());
}

class CalcIMC extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'IMC',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PageMainCalcIMC(),
    );
  }
}

