import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

class PageMainCalcIMC extends StatefulWidget {
  PageMainCalcIMC({Key key}) : super(key: key);

  @override
  _PageMainCalcIMC createState() => _PageMainCalcIMC();
}

class _PageMainCalcIMC extends State<PageMainCalcIMC> {
  TextEditingController controllerPeso = TextEditingController();
  TextEditingController controllerAltura = TextEditingController();
  String status = "";

  @override
  Widget build(BuildContext context) {
    //Size size = context.size;
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        title: Text("Calculadora de IMC", textAlign: TextAlign.center,),
      ),
      body: Center(
        child: Container(
          padding: EdgeInsets.all(20),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                'Peso:',
              ),
              TextField(
                controller: this.controllerPeso,
              ),
              Text(
                'Altura:',
              ),
              TextField(
                controller: this.controllerAltura,
              ),
              ElevatedButton(
                //style: style,
                onPressed: calcularIMC,
                child: const Text('Calcular'),
              ),
              Text("Status: " + this.status)
            ],
          ),
        )
      ), // This trailing comma makes auto-formatting nicer for build methods.
    );
  }

  calcularIMC(){
    double imc = double.parse(controllerPeso.text)/(double.parse(controllerAltura.text)*double.parse(controllerAltura.text));
    if(imc < 18.5){
      setState(() {
        this.status = "Magreza";
      });
    }
    if(imc >= 18.5 && imc < 24.9){
      setState(() {
        this.status = "Normal";
      });
    }
    if(imc >= 24.9 && imc < 30){
      setState(() {
        this.status = "Soprepeso";
      });
    }

    if(imc > 30){
      setState(() {
        this.status = "Obesidade";
      });
    }
  }
}
